from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext


class PythonGetenvAnnotator(AbstractAnnotator):
    """
    PythonGetenvAnnotator is an annotator class that identifies `os.getenv` calls in Python code.

    Methods:
    --------
    parse(ast: ParserRuleContext):
        Parses the provided abstract syntax tree (AST) to find all `os.getenv` calls,
        extracts their arguments, and yields annotations for each found string argument.

    Parameters:
    -----------
    ast : ParserRuleContext
        The abstract syntax tree (AST) to be parsed for `os.getenv` calls.
    """

    def parse(self, ast: ParserRuleContext):

        getenv_calls = findAll(ast, "Primary", filters={"primary": "os.getenv"})
        arguments = findAll(getenv_calls, "Arguments")
        strings = findAll(arguments, "Strings")

        for match in strings:
            yield Annotation(name="os.getenv", value=self.getText(match), context=match)
