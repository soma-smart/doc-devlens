from typing import Optional
from antlr4 import ParserRuleContext


class Annotation:
    """
    Represents an annotation with a name, optional value, and optional context.
    Attributes:
        name (str): The name of the annotation.
        path (str or None): The path associated with the annotation.
        value (str or None): The value of the annotation.
        line_start (int or None): The starting line number of the annotation in the source code.
        line_end (int or None): The ending line number of the annotation in the source code.
        column_start (int or None): The starting column number of the annotation in the source code.
        column_end (int or None): The ending column number of the annotation in the source code.
    Methods:
        __init__(name: str, value: Optional[str] = None, context: Optional[ParserRuleContext] = None):
            Initializes an Annotation instance with the given name, value, and context.
        set_path(path):
            Sets the path associated with the annotation.
        add_offset(offset):
            Adds an offset to the column_start and column_end attributes.
    """

    def __init__(
        self,
        name: str,
        value: Optional[str] = None,
        context: Optional[ParserRuleContext] = None,
    ):
        self.name = name
        self.path = None
        self.value = value
        if context:
            self.line_start = context.start.line
            self.line_end = context.stop.line
            self.column_start = context.start.column
            self.column_end = context.stop.column
        else:
            self.line_start = None
            self.line_end = None
            self.column_start = None
            self.column_end = None

    def set_path(self, path):
        self.path = path

    def add_offset(self, offset):
        if self.column_start is not None and self.column_end is not None:
            self.column_start += offset
            self.column_end += offset
