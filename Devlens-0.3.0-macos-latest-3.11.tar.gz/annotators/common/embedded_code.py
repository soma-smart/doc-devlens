from antlr4 import ParserRuleContext


class EmbeddedCode:
    """
    A class to represent embedded code within a specific context.

    Attributes:
    -----------
    code : str
        The embedded code as a string.
    parser : str
        The parser used to interpret the code.
    context : ParserRuleContext
        The context in which the code is embedded.

    Methods:
    --------
    __init__(code: str, parser: str, context: ParserRuleContext):
        Initializes the EmbeddedCode instance with the provided code, parser, and context.
    """

    def __init__(self, code: str, parser: str, context: ParserRuleContext):
        self.code = code
        self.parser = parser
        self.context = context
