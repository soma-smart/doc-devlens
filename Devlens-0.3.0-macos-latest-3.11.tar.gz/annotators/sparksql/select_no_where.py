from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext


class SQLNoWhereAnnotator(AbstractAnnotator):
    """
    SQLNoWhereAnnotator is a class that  identify SQL SELECT statements that do not contain a WHERE clause.

    Methods:
        parse(ast: ParserRuleContext):
            Parses the given abstract syntax tree (AST) to find all RegularQuerySpecification nodes.
            For each RegularQuerySpecification, it checks for the presence of SelectClause nodes.
            If a SelectClause node does not have an associated WhereClause, it yields an Annotation
            indicating a SELECT statement without a WHERE clause.

    Args:
        ast (ParserRuleContext): The abstract syntax tree representing the SQL query to be analyzed.

    Yields:
        Annotation: An annotation object with the name "Select_No_Where" for each SELECT statement
        that lacks a WHERE clause.
    """

    def parse(self, ast: ParserRuleContext):
        querySpecifications = findAll(ast, "RegularQuerySpecification")

        for querySpec in querySpecifications:
            selectClauses = findAll(querySpec, "SelectClause")
            for selectClause in selectClauses:

                whereClauses = findAll(querySpec, "WhereClause")

                if not whereClauses:
                    yield Annotation(
                        name="Select_No_Where", value=None, context=selectClause
                    )
