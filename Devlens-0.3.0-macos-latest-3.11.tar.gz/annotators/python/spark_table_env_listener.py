from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext

ENV_LIST = ["DEV", "INT", "REC", "PRD"]


class SparkTableEnvAnnotator(AbstractAnnotator):

    def parse(self, ast: ParserRuleContext):
        assignement = findAll(ast, "Assignment")
        primarySparkTable = findAll(
            assignement, "Primary", filters={"primary": "spark.table"}
        )
        string = findAll(primarySparkTable, "Strings")

        for match in string:
            starting_str = self.getText(match).strip('"').strip("'")

            matched_env = next(
                (env for env in ENV_LIST if starting_str.startswith(env)), None
            )
            if matched_env:
                yield Annotation(name="SparkTableEnv", value=matched_env, context=match)
