from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext


class PythonImportAnnotator(AbstractAnnotator):
    """
    PythonImportAnnotator is an annotator class that identifies import statements in Python code.

    Methods:
    --------
    parse(ast: ParserRuleContext):
        Parses the provided AST to find and yield annotations for Python import statements.
        It searches for import statements, import names, and dotted names within the AST.

        Parameters:
        -----------
        ast : ParserRuleContext
            The abstract syntax tree to be parsed for import statements.

        Yields:
        -------
        Annotation
            An annotation object containing the name "Import", the value of the import statement,
            and the context in which the import statement was found.
    """

    def parse(self, ast: ParserRuleContext):
        importStmts = findAll(ast, "Import_stmt")
        importNames = findAll(importStmts, "Import_name")
        names = findAll(importNames, "Dotted_name")

        for match in names:
            yield Annotation(name="Import", value=self.getText(match), context=match)
