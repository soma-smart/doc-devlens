from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext


class SparkSQLSelectWildcard(AbstractAnnotator):
    """
     SparkSQLSelectWildcard is an annotator class that identifies to find instances where a wildcard (*) is used in the SELECT clause.

    Methods:
        parse(ast: ParserRuleContext):
            Parses the provided AST to find and yield annotations for wildcard
            selections in the SELECT clause.

    Args:
        ast (ParserRuleContext): The abstract syntax tree of the Spark SQL query.

    Yields:
        Annotation: An annotation object for each detected wildcard selection
        in the SELECT clause.
    """

    def parse(self, ast: ParserRuleContext):
        selectClause = findAll(ast, "SelectClause")
        namedExpressionSeq = findAll(selectClause, "NamedExpressionSeq")
        star = findAll(namedExpressionSeq, "Star")

        for match in star:
            yield Annotation(
                name="Select_Wildcard",
                # value=None,
                context=match,
            )
