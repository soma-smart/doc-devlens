from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext

ENV_LIST = ["DEV", "INT", "REC", "PRD"]


class SparkSQLTableEnv(AbstractAnnotator):
    """
    SparkSQLTableEnv is an annotator class that identify environment-specific table names in Spark SQL queries.

    Methods:
        parse(ast: ParserRuleContext):
            Parses the provided AST to find table names and their corresponding environments.
            Yields annotations for each identified environment-specific table name.

            Parameters:
                ast (ParserRuleContext): The abstract syntax tree of the SQL query to be parsed.

            Yields:
                Annotation: An annotation object containing the name "Table_Env", the identified environment
                (as the value), and the context (location in the AST).
    """

    def parse(self, ast: ParserRuleContext):
        fromClause = findAll(ast, "FromClause")
        tableNames = findAll(fromClause, "TableName")
        multipartIdentifier1 = findAll(tableNames, "MultipartIdentifier")

        insertInto = findAll(ast, "InsertIntoTable")
        multipartIdentifier2 = findAll(insertInto, "MultipartIdentifier")

        all_names = multipartIdentifier1 + multipartIdentifier2

        for match in all_names:
            starting_str = self.getText(match).split("_")[0].upper()
            if starting_str in ENV_LIST:
                yield Annotation(name="Table_Env", value=starting_str, context=match)
