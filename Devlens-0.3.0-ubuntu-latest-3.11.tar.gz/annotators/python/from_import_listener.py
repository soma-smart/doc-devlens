from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext


class PythonFromImportAnnotator(AbstractAnnotator):
    """
    PythonFromImportAnnotator is an annotator class that identifies 'from ... import ...' statements in Python code.

    Methods:
    --------
    parse(ast: ParserRuleContext):
        Parses the given abstract syntax tree (AST) to find and annotate 'from ... import ...' statements.
        Yields annotations with the module and submodule names.

    Parameters:
    -----------
    ast : ParserRuleContext
        The abstract syntax tree (AST) of the Python code to be parsed.
    """

    def parse(self, ast: ParserRuleContext):
        importStmts = findAll(ast, "Import_stmt")
        importFroms = findAll(importStmts, "Import_from")

        for importFrom in importFroms:
            names = findAll(importFrom, "Dotted_name")
            importFromAsNames = findAll(importFrom, "Import_from_as_name")

            module = names[0].getText()
            for submodule in importFromAsNames:
                yield Annotation(
                    name="From_Import",
                    value=module + "." + submodule.getText(),
                    context=submodule,
                )
