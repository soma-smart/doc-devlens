from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext


class PythonHadoopTableAnnotator(AbstractAnnotator):
    """
    PythonHadoopTableAnnotator is an annotator class that identifies Hadoop table references in Python code.

    Methods:
    --------
    parse(ast: ParserRuleContext):
        Parses the given abstract syntax tree (AST) to find assignments related to
        `spark.table` and yields annotations for each identified Hadoop table reference.

    Parameters:
    -----------
    ast : ParserRuleContext
        The abstract syntax tree (AST) to be parsed for identifying Hadoop table references.
    """

    def parse(self, ast: ParserRuleContext):
        assignement = findAll(ast, "Assignment")
        primarySparkTable = findAll(
            assignement, "Primary", filters={"primary": "spark.table"}
        )
        string = findAll(primarySparkTable, "Strings")

        for match in string:
            yield Annotation(
                name="HadoopTable",
                value=self.getText(match).strip('"').strip("'"),
                context=match,
            )
