from antlr4 import ParserRuleContext, ParseTreeListener
from abc import abstractmethod
from src.file_analyze.common.abstract_text import AbstractText


class AbstractAnnotator(ParseTreeListener):
    """
    AbstractAnnotator is a base class for annotators that process parse trees.

    Attributes:
        text_processor (AbstractText): An instance of a text processor.

    Methods:
        getText(context: ParserRuleContext) -> str:
            Extracts text from the given parser rule context and processes it using the text processor.

        parse(ast: ParserRuleContext):
            Abstract method that must be implemented by subclasses to parse the given abstract syntax tree (AST).
    """

    def __init__(self, text_processor: AbstractText):
        self.text_processor = text_processor

    def getText(self, context: ParserRuleContext) -> str:
        text = context.getText()
        return self.text_processor.getText(text)

    @abstractmethod
    def parse(self, ast: ParserRuleContext):
        pass
