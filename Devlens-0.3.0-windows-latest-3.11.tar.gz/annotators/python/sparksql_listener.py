from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.embedded_code import EmbeddedCode

from antlr4 import ParserRuleContext


class SparkSQLAnnotator(AbstractAnnotator):
    """
    SparkSQLAnnotator is an annotator class that identifies EmbeddedCode objects for each
    detected query.

    Methods:
    --------
    parse(ast: ParserRuleContext):
        Parses the provided AST to find Spark SQL queries and yields EmbeddedCode
        objects for each detected query.

        Parameters:
        -----------
        ast : ParserRuleContext
            The abstract syntax tree to be parsed for Spark SQL queries.

        Yields:
        -------
        EmbeddedCode
            An object containing the extracted Spark SQL query, the parser type,
            and the context in which the query was found.
    """

    def parse(self, ast: ParserRuleContext):
        assignement = findAll(ast, "Assignment")
        primarySparkSql = findAll(assignement, "Primary", {"primary": "spark.sql"})
        string = findAll(primarySparkSql, "Strings")

        for match in string:
            yield EmbeddedCode(
                code=self.getText(match).strip('"').strip("'"),
                parser="sparksql",
                context=match,
            )
