from antlr4 import ParserRuleContext, TerminalNode


def findAll(
    nodes: list[ParserRuleContext] | ParserRuleContext, node_name, filters: dict = {}
) -> list[ParserRuleContext]:
    """
    Recursively searches for nodes in the provided list that match the specified context name and filters.
    Args:
        nodes (list[ParserRuleContext]): A list of nodes to search through.
        context_name (str): The name of the context to match against the node types.
        filters (dict): A dictionary of filters to apply to each node.
    Returns:
        list[ParserRuleContext]: A list of nodes that match the specified context name and filters.
    """
    context_name = node_name.lower() + "context"

    if isinstance(nodes, ParserRuleContext):
        return _findAll([nodes], context_name, filters)
    return _findAll(nodes, context_name, filters)


def _findAll(
    nodes: list[ParserRuleContext], context_name: str, filters: dict
) -> list[ParserRuleContext]:

    matching = []
    for node in nodes:
        if type(node).__name__.lower() == context_name and _validateFilter(
            node, filters
        ):
            matching.append(node)
            continue

        for child in node.getChildren():
            if isinstance(child, TerminalNode):
                continue
            matching = matching + _findAll([child], context_name, filters)
    return matching


def _validateFilter(node: ParserRuleContext, filters: dict) -> bool:
    for key in filters.keys():
        if key == "":  # To access text of the context directly
            context = node
        else:  # To access a specific method of the context
            context = getattr(node, key)()
        if not context:
            return False

        if context.getText() != filters[key]:
            return False
    return True
