from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation

from antlr4 import ParserRuleContext


class SparkSQLHadoopTableAnnotator(AbstractAnnotator):
    """
    SparkSQLHadoopTableAnnotator is an annotator class that identifies Hadoop table references in Spark SQL queries.

    Methods:
    --------
    parse(ast: ParserRuleContext):
        Parses the given abstract syntax tree (AST) to find and yield annotations for Hadoop table references.
        It looks for 'FromClause' and 'Relation' nodes within the AST and generates annotations with the name
        'HadoopTable' for each match found.
    """

    def parse(self, ast: ParserRuleContext):
        fromClauses = findAll(ast, "FromClause")
        relations = findAll(fromClauses, "Relation")

        for match in relations:
            yield Annotation(
                name="HadoopTable", value=self.getText(match), context=match
            )
