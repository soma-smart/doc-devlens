from annotators.common.abstract_annotator import AbstractAnnotator
from annotators.common.search import findAll
from annotators.common.annotation import Annotation
from antlr4 import ParserRuleContext
from file_analyze.common.env_var_utils import EnvVarUtils


class SparkSQLEnvInTableName(AbstractAnnotator):
    """
    SparkSQLEnvInTableName is an annotator class that identifies environment variables in table names within a Spark SQL query.

    Methods:
        parse(ast: ParserRuleContext):
            Parses the given abstract syntax tree (AST) to find table names that contain environment variables.
            Yields an Annotation for each table name that includes an environment variable.

            Args:
                ast (ParserRuleContext): The abstract syntax tree of the SQL query.

            Yields:
                Annotation: An annotation object containing the name "Env_in_Table_Name", the value of the table name with the environment variable, and the context of the match.
    """

    def parse(self, ast: ParserRuleContext):
        fromClause = findAll(ast, "FromClause")
        tableNames = findAll(fromClause, "TableName")
        multipartIdentifier = findAll(tableNames, "MultipartIdentifier")

        for match in multipartIdentifier:

            if EnvVarUtils.has_var_env(match.getText()):
                yield Annotation(
                    name="Env_in_Table_Name", value=self.getText(match), context=match
                )
